package com.kanban.model;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
